# 🚀 Deployment Guide

## Quick Start (5 минут)

### 1. Установка Rust

```bash
# Linux/Mac
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
source $HOME/.cargo/env

# Windows
# Скачайте и установите: https://rustup.rs/
```

### 2. Создание проекта

```bash
# Создайте директорию
mkdir polymarket-bot
cd polymarket-bot

# Скопируйте все файлы из артефактов:
# - Cargo.toml в корень
# - Все файлы src/*.rs в папку src/
# - src/bin/mempool_monitor.rs в папку src/bin/
# - .env.example в корень
```

### 3. Структура проекта

```
polymarket-bot/
├── Cargo.toml
├── .env.example
├── .env                    # создайте из .env.example
├── build.sh               # опционально
└── src/
    ├── main.rs
    ├── types.rs
    ├── config.rs
    ├── api.rs
    ├── watcher.rs
    ├── sizing.rs
    ├── risk.rs
    ├── executor.rs
    └── bin/
        └── mempool_monitor.rs
```

### 4. Настройка .env

```bash
# Скопируйте пример
cp .env.example .env

# Отредактируйте своими данными
nano .env  # или vim, или любой редактор
```

**Обязательные параметры:**

```env
# Адреса китов для копирования (найдите на Polymarket)
WALLETS_TO_TRACK=0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb

# Ваш кошелек
YOUR_WALLET=0xВАШ_АДРЕС

# Ваш приватный ключ (БЕЗ 0x префикса!)
PRIVATE_KEY=ваш_приватный_ключ_64_символа

# RPC для Polygon (зарегистрируйтесь на Alchemy)
RPC_URL=wss://polygon-mainnet.g.alchemy.com/v2/ВАШИ_API_KEY
```

### 5. Сборка

```bash
# Простой способ
cargo build --release

# Или используйте скрипт (Linux/Mac)
chmod +x build.sh
./build.sh
```

### 6. Запуск

```bash
# Основной бот
cargo run --release --bin polymarket-bot

# Или напрямую
./target/release/polymarket-bot
```

---

## 🔑 Получение API Keys

### Alchemy (Рекомендуется)

1. Регистрация: https://www.alchemy.com/
2. Create App → Polygon Mainnet
3. Скопируйте WebSocket URL
4. Вставьте в `.env` как `RPC_URL`

### Infura (Альтернатива)

1. Регистрация: https://infura.io/
2. Create Project → Polygon
3. Скопируйте WebSocket endpoint
4. Вставьте в `.env`

---

## 🐋 Поиск китов для копирования

### Где найти адреса успешных трейдеров:

1. **Polymarket Leaderboard**
   - https://polymarket.com/leaderboard
   - Сортировка по profit

2. **Dune Analytics**
   - Поиск по Polymarket dashboards
   - Анализ успешных кошельков

3. **Twitter/X**
   - Трейдеры часто делятся своими адресами
   - Ищите `#Polymarket` или `$POLY`

4. **Проверка кита**
   ```
   # Посмотрите историю на Polygonscan
   https://polygonscan.com/address/0xADRESS
   
   # Проверьте P&L на Polymarket
   ```

**Критерии выбора кита:**
- ✅ Положительный P&L за последние 3 месяца
- ✅ Регулярная активность (трейды каждую неделю)
- ✅ Разумный размер сделок ($50-$500)
- ❌ Избегайте китов с огромными сделками (>$10k)
- ❌ Избегайте неактивных кошельков

---

## 💻 VPS Deployment

### Зачем нужен VPS?

- 24/7 работа
- Стабильное соединение
- Низкая латентность

### Рекомендуемые провайдеры:

**1. DigitalOcean** ($6/month)
```bash
# Basic Droplet
- 1 GB RAM
- 1 vCPU
- Ubuntu 22.04
```

**2. Vultr** ($6/month)
```bash
# Cloud Compute
- 1 GB RAM
- 1 vCPU
- Location: New York или Frankfurt
```

**3. Hetzner** (€4.5/month)
```bash
# CX11
- 2 GB RAM
- 1 vCPU
- Location: Germany
```

### Настройка VPS:

```bash
# 1. Подключение
ssh root@YOUR_VPS_IP

# 2. Обновление системы
apt update && apt upgrade -y

# 3. Установка Rust
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
source $HOME/.cargo/env

# 4. Установка зависимостей
apt install -y build-essential pkg-config libssl-dev

# 5. Клонирование проекта
mkdir polymarket-bot
cd polymarket-bot
# Загрузите файлы через scp или git

# 6. Настройка .env
nano .env
# Вставьте ваши настройки

# 7. Сборка
cargo build --release

# 8. Запуск в фоне
nohup ./target/release/polymarket-bot > bot.log 2>&1 &

# 9. Проверка логов
tail -f bot.log
```

### Автозапуск (systemd):

Создайте файл `/etc/systemd/system/polymarket-bot.service`:

```ini
[Unit]
Description=Polymarket Copy Trading Bot
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/root/polymarket-bot
ExecStart=/root/polymarket-bot/target/release/polymarket-bot
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

Запуск:
```bash
systemctl daemon-reload
systemctl enable polymarket-bot
systemctl start polymarket-bot
systemctl status polymarket-bot
```

---

## 🔍 Мониторинг

### Проверка логов:

```bash
# Если запущен через systemd
journalctl -u polymarket-bot -f

# Если через nohup
tail -f bot.log

# Поиск ошибок
grep "ERROR" bot.log
grep "❌" bot.log
```

### Важные метрики:

```
📈 Daily stats: X trades, $Y volume
```
- Отслеживайте ежедневно
- Убедитесь что не превышаете лимиты

```
⚠️  CIRCUIT BREAKER TRIPPED
```
- Бот остановлен из-за ошибок
- Проверьте причину
- Перезапустите после исправления

---

## 🛡️ Безопасность

### 1. Защита приватного ключа

```bash
# Права доступа только для владельца
chmod 600 .env

# Проверка
ls -la .env
# должно быть: -rw-------
```

### 2. Firewall

```bash
# Разрешить только SSH
ufw allow 22/tcp
ufw enable
```

### 3. Резервные копии

```bash
# Бэкап конфига
cp .env .env.backup

# Сохраните локально, НЕ в git!
```

### 4. Ротация ключей

- Используйте отдельный кошелек только для бота
- Держите минимальный баланс
- Регулярно выводите профит

---

## 🐛 Troubleshooting

### "error: linking with `cc` failed"

```bash
# Ubuntu/Debian
apt install build-essential

# Alpine
apk add build-base
```

### "WebSocket connection failed"

1. Проверьте `RPC_URL`
2. Проверьте квоту Alchemy/Infura
3. Попробуйте другой провайдер

### "Failed to place order"

1. Проверьте баланс кошелька
2. Проверьте `PRIVATE_KEY` (64 символа, без 0x)
3. Проверьте что кошелек approved для Polymarket

### "Circuit breaker tripped"

1. Проверьте логи: `grep ERROR bot.log`
2. Исправьте проблему
3. Перезапустите бота
4. Бот автоматически сбросит circuit breaker

---

## 📊 Performance Tuning

### Для высокой нагрузки:

```env
# Увеличьте лимиты
MAX_DAILY_VOLUME=10000.0
MAX_EXPOSURE_PER_EVENT=2000.0

# Более агрессивные retry
RETRY_ATTEMPTS=6
RETRY_DELAY_MS=300
```

### Для консервативной торговли:

```env
# Уменьшите лимиты
MAX_DAILY_VOLUME=500.0
MAX_EXPOSURE_PER_EVENT=100.0
MIN_LIQUIDITY=5000.0

# Более строгий circuit breaker
CB_CONSECUTIVE_TRIGGER=2
```

---

## 🎯 Best Practices

1. **Начните с малого**
   - FIXED_STAKE=10.0
   - MAX_DAILY_VOLUME=100.0
   - Один кит для начала

2. **Мониторьте первые 24 часа**
   - Проверяйте логи каждые 2-3 часа
   - Убедитесь что сделки исполняются
   - Проверьте комиссии

3. **Оптимизируйте постепенно**
   - Если все работает - увеличьте stakes
   - Добавьте больше китов
   - Экспериментируйте с sizing modes

4. **Отслеживайте P&L**
   - Создайте таблицу в Excel/Sheets
   - Записывайте каждую сделку
   - Считайте ROI еженедельно

---

## 📞 Support

Если что-то не работает:

1. Проверьте логи (90% проблем видно там)
2. Проверьте все переменные в `.env`
3. Убедитесь что используете последнюю версию Rust
4. Проверьте баланс кошелька и RPC квоту

---

**Good luck trading! 🚀**