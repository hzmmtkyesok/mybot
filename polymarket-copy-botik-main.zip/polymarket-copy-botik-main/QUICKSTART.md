# ⚡ Quick Start

Минимальная инструкция для быстрого запуска бота.

## 📋 Prerequisites

```bash
# 1. Установите Rust (если еще нет)
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
source $HOME/.cargo/env

# 2. Проверка
rustc --version
cargo --version
```

## 🚀 Setup (3 минуты)

```bash
# 1. Создайте проект
mkdir polymarket-bot && cd polymarket-bot

# 2. Создайте структуру
mkdir -p src/bin

# 3. Скопируйте все файлы из артефактов в правильные места:
#
#    Cargo.toml          → корень проекта
#    .env.example        → корень проекта
#    
#    main.rs             → src/
#    types.rs            → src/
#    config.rs           → src/
#    api.rs              → src/
#    watcher.rs          → src/
#    sizing.rs           → src/
#    risk.rs             → src/
#    executor.rs         → src/
#    
#    mempool_monitor.rs  → src/bin/

# 4. Создайте .env
cp .env.example .env
```

## ⚙️ Configuration (2 минуты)

Отредактируйте `.env`:

```bash
nano .env  # или vim, code, etc.
```

**Минимальная конфигурация:**

```env
# Киты для копирования (замените на реальные адреса)
WALLETS_TO_TRACK=0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb

# Ваш кошелек
YOUR_WALLET=0xВАШ_АДРЕС_СЮДА

# Ваш приватный ключ (БЕЗ 0x!)
PRIVATE_KEY=ваш_64_символа_ключ_без_0x

# RPC endpoint (получите на alchemy.com)
RPC_URL=wss://polygon-mainnet.g.alchemy.com/v2/ВАШ_ALCHEMY_KEY

# Sizing - начните с малого!
SIZING_MODE=fixed
FIXED_STAKE=10.0
MIN_STAKE=5.0
MAX_STAKE=50.0

# Risk limits - консервативные для начала
MAX_EXPOSURE_PER_EVENT=100.0
MAX_DAILY_VOLUME=500.0
MIN_LIQUIDITY=1000.0
```

## 🔧 Build & Run

```bash
# Сборка (первый раз займет 5-10 минут)
cargo build --release

# Запуск
cargo run --release --bin polymarket-bot
```

**Ожидайте вывод:**

```
🚀 Polymarket Copy Trading Bot Starting...
✅ Configuration loaded
   Tracking 1 wallets
   Sizing mode: Fixed
   Your wallet: 0x12345678...
✅ Components initialized
✅ WebSocket watchers started
🎯 Bot is now live and monitoring trades...
```

## 🎯 Что дальше?

### Если всё работает:

1. **Наблюдайте 24 часа** - не трогайте настройки
2. **Проверяйте логи** каждые 2-3 часа
3. **Записывайте сделки** в таблицу
4. **Считайте P&L** в конце дня

### Если бот исполнил сделки успешно:

```env
# Увеличьте stakes постепенно
FIXED_STAKE=25.0
MAX_STAKE=100.0
MAX_DAILY_VOLUME=1000.0
```

### Если хотите копировать больше китов:

```env
# Добавьте через запятую
WALLETS_TO_TRACK=0xwhale1,0xwhale2,0xwhale3
```

## 🐛 Troubleshooting

### Ошибка: "WALLETS_TO_TRACK not set"

```bash
# Проверьте .env файл
cat .env | grep WALLETS

# Должно быть:
WALLETS_TO_TRACK=0x...
```

### Ошибка: "Failed to connect to WebSocket"

```bash
# Проверьте RPC_URL
cat .env | grep RPC_URL

# Проверьте квоту на Alchemy
# Попробуйте другой endpoint
```

### Ошибка: "Failed to place order"

```bash
# 1. Проверьте баланс кошелька
# 2. Проверьте PRIVATE_KEY (64 символа, без 0x)
# 3. Убедитесь что кошелек approved для Polymarket
```

### Ошибка при компиляции

```bash
# Обновите Rust
rustup update

# Очистите кэш
cargo clean

# Пересоберите
cargo build --release
```

## 📊 Мониторинг

```bash
# Следите за логами в реальном времени
cargo run --release --bin polymarket-bot

# В отдельном терминале можете проверять:
# - Баланс кошелька на Polygonscan
# - Открытые позиции на Polymarket
# - Историю сделок
```

## 🛑 Остановка бота

```bash
# Ctrl+C в терминале

# Или если запущен в фоне
pkill polymarket-bot
```

## 💡 Pro Tips

1. **Начинайте с $10 stakes** - не рискуйте сразу большими суммами
2. **Копируйте только ПРОВЕРЕННЫХ китов** - смотрите их историю на Polymarket
3. **Устанавливайте СТРОГИЕ лимиты** - лучше пропустить сделку чем потерять деньги
4. **Проверяйте ликвидность** - MIN_LIQUIDITY не меньше $1000
5. **Следите за комиссиями** - они съедают прибыль!

## 📚 Дополнительные ресурсы

- **Полная документация**: `README_FULL.md`
- **Deployment на VPS**: `DEPLOYMENT.md`
- **Поиск китов**: Polymarket Leaderboard
- **Получение API keys**: Alchemy.com, Infura.io

---

**Готово! Ваш бот должен работать!** 🎉

Если что-то не так - читайте логи, они всегда говорят что не так.

**ВАЖНО:**  
- ✅ Начните с малых сумм ($10-50)  
- ✅ Тестируйте 24-48 часов  
- ✅ Записывайте все сделки  
- ✅ Анализируйте результаты  
- ❌ Не вкладывайте больше чем готовы потерять  

Good luck! 🚀